import 'dart:async';
import '../../data/database/app_database.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../data/models/dtc_code.dart';
import '../../data/models/live_data.dart';
import '../../data/models/vehicle_info.dart';
import '../../data/models/diagnostic_result.dart';
import '../../data/models/ai_explanation.dart';
import '../../data/datasources/obd/obd_data_source.dart';
import '../../data/datasources/obd/demo_obd_source.dart';
import '../../data/datasources/obd/real_obd_source.dart';
import '../../data/datasources/ai/gemini_service.dart';
import '../../domain/engine/diagnostic_engine.dart';
import '../../domain/engine/health_score_calculator.dart';
import '../../core/l10n/app_locale.dart';

// === Language Provider ===
final languageProvider = StateNotifierProvider<LanguageNotifier, String>((ref) {
  return LanguageNotifier();
});

class LanguageNotifier extends StateNotifier<String> {
  LanguageNotifier() : super('ru') {
    _loadLanguage();
  }

  Future<void> _loadLanguage() async {
    final prefs = await SharedPreferences.getInstance();
    state = prefs.getString('language') ?? 'ru';
  }

  Future<void> setLanguage(String lang) async {
    state = lang;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('language', lang);
  }
}

final localeProvider = Provider<AppLocale>((ref) {
  final lang = ref.watch(languageProvider);
  return AppLocale(lang);
});

// === Connection State ===
enum ConnectionStatus { disconnected, scanning, connecting, connected, error }

final connectionStatusProvider = StateProvider<ConnectionStatus>((ref) {
  return ConnectionStatus.disconnected;
});

final isDemoModeProvider = StateProvider<bool>((ref) => false);

// === OBD Source ===
final demoObdSourceProvider = Provider<DemoObdSource>((ref) => DemoObdSource());
final realObdSourceProvider = Provider<RealObdSource>((ref) => RealObdSource());

final obdDataSourceProvider = Provider<ObdDataSource>((ref) {
  final isDemo = ref.watch(isDemoModeProvider);
  return isDemo ? ref.watch(demoObdSourceProvider) : ref.watch(realObdSourceProvider);
});

// === Vehicle Info ===
final vehicleInfoProvider = StateProvider<VehicleInfo?>((ref) => null);

// === Live Data ===
final liveDataProvider = StateNotifierProvider<LiveDataNotifier, LiveData?>((ref) {
  return LiveDataNotifier(ref);
});

class LiveDataNotifier extends StateNotifier<LiveData?> {
  final Ref ref;
  StreamSubscription? _subscription;

  LiveDataNotifier(this.ref) : super(null);

  void startListening() {
    final obd = ref.read(obdDataSourceProvider);
    _subscription?.cancel();
    _subscription = obd.getLiveDataStream().listen((data) {
      state = data;
    });
  }

  void stopListening() {
    _subscription?.cancel();
    state = null;
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }
}

// === DTC Codes ===
final dtcCodesProvider = StateNotifierProvider<DtcCodesNotifier, List<DtcCode>>((ref) {
  return DtcCodesNotifier(ref);
});

class DtcCodesNotifier extends StateNotifier<List<DtcCode>> {
  final Ref ref;

  DtcCodesNotifier(this.ref) : super([]);

  Future<void> scanDtcCodes() async {
    final obd = ref.read(obdDataSourceProvider);
    state = await obd.readDtcCodes();
  }

  Future<void> clearDtcCodes() async {
    final obd = ref.read(obdDataSourceProvider);
    await obd.clearDtcCodes();
    state = [];
  }

  void setDtcCodes(List<DtcCode> codes) {
    state = codes;
  }
}

// === Diagnostic Engine ===
final diagnosticEngineProvider = Provider<DiagnosticEngine>((ref) {
  return DiagnosticEngine();
});

// === Diagnostic Results ===
final diagnosticResultsProvider = StateProvider<Map<String, DiagnosticResult>>((ref) => {});

// === AI Explanation (Gemini) ===
final geminiServiceProvider = StateNotifierProvider<GeminiNotifier, String>((ref) {
  return GeminiNotifier();
});

class GeminiNotifier extends StateNotifier<String> {
  GeminiNotifier() : super('') {
    _loadKey();
  }

  Future<void> _loadKey() async {
    final prefs = await SharedPreferences.getInstance();
    state = prefs.getString('gemini_api_key') ?? '';
  }

  Future<void> setApiKey(String key) async {
    state = key;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('gemini_api_key', key);
  }

  GeminiService get service => GeminiService(apiKey: state);
}
final aiExplanationsProvider = StateProvider<Map<String, AiExplanation>>((ref) => {});

final aiLoadingProvider = StateProvider<bool>((ref) => false);

// === Health Score ===
final healthScoreProvider = Provider<int>((ref) {
  final dtcs = ref.watch(dtcCodesProvider);
  final liveData = ref.watch(liveDataProvider);
  
  if (liveData == null) return -1; // Not calculated yet
  
  return HealthScoreCalculator.calculate(
    activeDtcs: dtcs,
    liveData: liveData,
  );
});

// === Database ===
final appDatabaseProvider = Provider<AppDatabase>((ref) {
  final db = AppDatabase();
  ref.onDispose(() => db.close());
  return db;
});

// === Diagnostic History (Drift Stream) ===
final diagnosticHistoryProvider = StreamProvider<List<DiagnosticSession>>((ref) {
  final db = ref.watch(appDatabaseProvider);
  return db.watchAllSessions();
});

// === Selected DTC for analysis ===
final selectedDtcProvider = StateProvider<DtcCode?>((ref) => null);

// === Navigation index ===
final bottomNavIndexProvider = StateProvider<int>((ref) => 0);
