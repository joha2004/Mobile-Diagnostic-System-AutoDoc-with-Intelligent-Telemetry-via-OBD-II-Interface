import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/l10n/app_locale.dart';
import 'dart:math';
import 'dart:async';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

class ConnectionScreen extends ConsumerStatefulWidget {
  const ConnectionScreen({super.key});

  @override
  ConsumerState<ConnectionScreen> createState() => _ConnectionScreenState();
}

class _ConnectionScreenState extends ConsumerState<ConnectionScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _radarController;
  bool _isScanning = false;
  final List<ScanResult> _devices = [];
  StreamSubscription<List<ScanResult>>? _scanSub;

  @override
  void initState() {
    super.initState();
    _radarController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    );
  }

  @override
  void dispose() {
    _radarController.dispose();
    _scanSub?.cancel();
    FlutterBluePlus.stopScan();
    super.dispose();
  }

  Future<void> _startScan() async {
    setState(() {
      _isScanning = true;
      _devices.clear();
    });
    _radarController.repeat();

    _scanSub?.cancel();
    _scanSub = FlutterBluePlus.scanResults.listen((results) {
      if (mounted) {
        setState(() {
          // Filter out unnamed or unconnectable devices if desired
          _devices.clear();
          _devices.addAll(results.where((r) => r.device.platformName.isNotEmpty));
        });
      }
    });

    try {
       await FlutterBluePlus.startScan(timeout: const Duration(seconds: 10));
    } catch (e) {
       debugPrint('Scan error: $e');
    }

    if (mounted) {
      setState(() {
        _isScanning = false;
      });
      _radarController.stop();
    }
  }

  Future<void> _connectToDevice(ScanResult scanResult) async {
    // Stop scanning before connect
    await FlutterBluePlus.stopScan();

    ref.read(connectionStatusProvider.notifier).state = ConnectionStatus.connecting;
    ref.read(isDemoModeProvider.notifier).state = false;

    final realObd = ref.read(realObdSourceProvider);
    final success = await realObd.connect(scanResult.device);

    if (success && mounted) {
      ref.read(connectionStatusProvider.notifier).state = ConnectionStatus.connected;
      ref.read(vehicleInfoProvider.notifier).state = realObd.getVehicleInfo();
      ref.read(liveDataProvider.notifier).startListening();
      
      await ref.read(dtcCodesProvider.notifier).scanDtcCodes();
      ref.read(bottomNavIndexProvider.notifier).state = 1; // Go to dashboard
    } else if (mounted) {
      ref.read(connectionStatusProvider.notifier).state = ConnectionStatus.error;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to connect to OBD device')),
      );
    }
  }

  Future<void> _startDemoMode() async {
    ref.read(connectionStatusProvider.notifier).state = ConnectionStatus.connecting;
    
    final demo = ref.read(demoObdSourceProvider);
    await demo.connect();
    
    ref.read(connectionStatusProvider.notifier).state = ConnectionStatus.connected;
    ref.read(isDemoModeProvider.notifier).state = true;
    ref.read(vehicleInfoProvider.notifier).state = demo.getVehicleInfo();
    ref.read(liveDataProvider.notifier).startListening();
    await ref.read(dtcCodesProvider.notifier).scanDtcCodes();
    
    ref.read(bottomNavIndexProvider.notifier).state = 1;
  }

  @override
  Widget build(BuildContext context) {
    final t = ref.watch(localeProvider);
    final status = ref.watch(connectionStatusProvider);

    return Scaffold(
      backgroundColor: AppColors.backgroundDark,
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 20),
            // Title
            Text(
              t.get('connection_title'),
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            const SizedBox(height: 8),
            Text(
              status == ConnectionStatus.connected
                  ? t.get('connection_connected')
                  : t.get('connection_disconnected'),
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: status == ConnectionStatus.connected
                    ? AppColors.success
                    : AppColors.textTertiary,
              ),
            ),
            
            const SizedBox(height: 30),

            // Radar Animation
            Expanded(
              flex: 3,
              child: Center(
                child: SizedBox(
                  width: 260,
                  height: 260,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      // Radar circles with glow
                      ...List.generate(3, (i) => Container(
                        width: 100.0 + i * 80,
                        height: 100.0 + i * 80,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(color: AppColors.primary.withAlpha(10), blurRadius: 40, spreadRadius: 10)
                          ],
                          border: Border.all(
                            color: AppColors.primary.withAlpha(20 + i * 20),
                            width: 1.5,
                          ),
                        ),
                      )),
                      
                      // Radar sweep
                      if (_isScanning)
                        AnimatedBuilder(
                          animation: _radarController,
                          builder: (context, child) {
                            return Transform.rotate(
                              angle: _radarController.value * 2 * pi,
                              child: CustomPaint(
                                size: const Size(260, 260),
                                painter: _RadarSweepPainter(),
                              ),
                            );
                          },
                        ),
                      
                      // Center icon
                      Container(
                        width: 70,
                        height: 70,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: status == ConnectionStatus.connected
                              ? AppColors.successGradient
                              : AppColors.primaryGradient,
                          boxShadow: [
                            BoxShadow(
                              color: (status == ConnectionStatus.connected
                                  ? AppColors.success
                                  : AppColors.primary).withAlpha(100),
                              blurRadius: 30,
                              spreadRadius: 10,
                            ),
                            BoxShadow(
                              color: Colors.white.withAlpha(50),
                              blurRadius: 10,
                              spreadRadius: -2,
                            ),
                          ],
                          border: Border.all(color: Colors.white.withAlpha(80), width: 1),
                        ),
                        child: Icon(
                          status == ConnectionStatus.connected
                              ? Icons.check
                              : Icons.bluetooth_searching,
                          color: Colors.white,
                          size: 32,
                        ),
                      ),

                      // Device dots on radar
                      ..._devices.asMap().entries.map((entry) {
                        final i = entry.key;
                        final angle = (i * 1.3 + 0.8);
                        final radius = 80.0 + (i % 3) * 30;
                        return Positioned(
                          left: 130 + cos(angle) * radius - 8,
                          top: 130 + sin(angle) * radius - 8,
                          child: _DeviceDot(
                            device: entry.value,
                            onTap: () => _connectToDevice(entry.value),
                          ),
                        );
                      }),
                    ],
                  ),
                ),
              ),
            ),

            // Device list
            if (_devices.isNotEmpty)
              Expanded(
                flex: 2,
                child: ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: _devices.length,
                  itemBuilder: (context, index) {
                    final device = _devices[index];
                    return _DeviceCard(
                      device: device,
                      locale: t,
                      status: status,
                      onConnect: () => _connectToDevice(device),
                    );
                  },
                ),
              ),

            // Buttons
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  if (status != ConnectionStatus.connected) ...[
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: _isScanning || status == ConnectionStatus.connecting
                            ? null
                            : _startScan,
                        icon: Icon(_isScanning ? Icons.hourglass_top : Icons.search),
                        label: Text(
                          _isScanning
                              ? t.get('connection_searching')
                              : t.get('connection_scanning'),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: status == ConnectionStatus.connecting
                            ? null
                            : _startDemoMode,
                        icon: const Icon(Icons.play_circle_outline),
                        label: Text(t.get('connection_demo_mode')),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Text(
                        t.get('connection_demo_desc'),
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                  ],
                  if (status == ConnectionStatus.connecting)
                    const Padding(
                      padding: EdgeInsets.all(20),
                      child: CircularProgressIndicator(color: AppColors.primary),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DeviceDot extends StatelessWidget {
  final ScanResult device;
  final VoidCallback onTap;

  const _DeviceDot({required this.device, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 16,
        height: 16,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: AppColors.primary,
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.withAlpha(120),
              blurRadius: 10,
            ),
          ],
        ),
      ),
    );
  }
}

class _DeviceCard extends StatelessWidget {
  final ScanResult device;
  final AppLocale locale;
  final ConnectionStatus status;
  final VoidCallback onConnect;

  const _DeviceCard({
    required this.device,
    required this.locale,
    required this.status,
    required this.onConnect,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppColors.surface.withAlpha(200),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.primary.withAlpha(40), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withAlpha(10),
            blurRadius: 20,
            spreadRadius: 2,
          )
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.primary.withAlpha(30),
            ),
            child: const Icon(Icons.bluetooth, color: AppColors.primary, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  device.device.platformName,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: AppColors.textPrimary,
                  ),
                ),
                Text(
                  'ID: ${device.device.remoteId.str}',
                  style: const TextStyle(fontSize: 12, color: AppColors.textTertiary),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: AppColors.surfaceLight,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.signal_cellular_alt,
                  size: 14,
                  color: device.rssi > -60 ? AppColors.success : AppColors.warning,
                ),
                const SizedBox(width: 4),
                Text(
                  '${device.rssi} dBm',
                  style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RadarSweepPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final paint = Paint()
      ..shader = SweepGradient(
        startAngle: 0,
        endAngle: pi / 2,
        colors: [
          AppColors.primary.withAlpha(0),
          AppColors.primary.withAlpha(60),
        ],
      ).createShader(Rect.fromCircle(center: center, radius: size.width / 2));
    
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: size.width / 2),
      -pi / 2,
      pi / 2,
      true,
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
