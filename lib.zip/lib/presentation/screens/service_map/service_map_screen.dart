import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../../providers/app_providers.dart';
import '../../../core/theme/app_colors.dart';

class ServiceMapScreen extends ConsumerStatefulWidget {
  const ServiceMapScreen({super.key});

  @override
  ConsumerState<ServiceMapScreen> createState() => _ServiceMapScreenState();
}

class _ServiceMapScreenState extends ConsumerState<ServiceMapScreen> {
  String _selectedCategory = 'all';

  // Demo service centers data
  final List<_ServiceCenter> _centers = [
    _ServiceCenter('АвтоДоктор Сервис', 'diagnostics', 51.1694, 71.4491, 4.7, '2.3 км'),
    _ServiceCenter('ЭлектроМастер', 'electrician', 51.1650, 71.4550, 4.5, '3.1 км'),
    _ServiceCenter('МоторПро', 'engine', 51.1720, 71.4400, 4.8, '1.8 км'),
    _ServiceCenter('КарФикс Диагностика', 'diagnostics', 51.1600, 71.4600, 4.2, '4.5 км'),
    _ServiceCenter('АвтоЭлектрик 24', 'electrician', 51.1750, 71.4350, 4.6, '2.9 км'),
    _ServiceCenter('ТурбоМоторс', 'engine', 51.1680, 71.4520, 4.4, '3.7 км'),
  ];

  List<_ServiceCenter> get _filteredCenters {
    if (_selectedCategory == 'all') return _centers;
    return _centers.where((c) => c.category == _selectedCategory).toList();
  }

  @override
  Widget build(BuildContext context) {
    final t = ref.watch(localeProvider);
    
    return Scaffold(
      backgroundColor: AppColors.backgroundDark,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(t.get('map_title'), style: Theme.of(context).textTheme.headlineSmall),
            ),
            
            // Category filter chips
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _CategoryChip(
                      label: t.get('map_all'),
                      icon: Icons.apps,
                      isActive: _selectedCategory == 'all',
                      onTap: () => setState(() => _selectedCategory = 'all'),
                    ),
                    const SizedBox(width: 8),
                    _CategoryChip(
                      label: t.get('map_diagnostics'),
                      icon: Icons.search,
                      isActive: _selectedCategory == 'diagnostics',
                      onTap: () => setState(() => _selectedCategory = 'diagnostics'),
                    ),
                    const SizedBox(width: 8),
                    _CategoryChip(
                      label: t.get('map_electrician'),
                      icon: Icons.electrical_services,
                      isActive: _selectedCategory == 'electrician',
                      onTap: () => setState(() => _selectedCategory = 'electrician'),
                    ),
                    const SizedBox(width: 8),
                    _CategoryChip(
                      label: t.get('map_engine_specialist'),
                      icon: Icons.build,
                      isActive: _selectedCategory == 'engine',
                      onTap: () => setState(() => _selectedCategory = 'engine'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),

            // Map (OpenStreetMap)
            Expanded(
              flex: 3,
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 16),
                clipBehavior: Clip.antiAlias,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.border),
                ),
                child: FlutterMap(
                  options: const MapOptions(
                    initialCenter: LatLng(51.1694, 71.4491),
                    initialZoom: 13,
                  ),
                  children: [
                    TileLayer(
                      urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                      userAgentPackageName: 'com.example.autodokdor1',
                    ),
                    MarkerLayer(
                      markers: _filteredCenters.map((center) => Marker(
                        point: LatLng(center.lat, center.lng),
                        width: 40,
                        height: 40,
                        child: Container(
                          decoration: BoxDecoration(
                            color: _categoryColor(center.category),
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 2),
                            boxShadow: [
                              BoxShadow(
                                color: _categoryColor(center.category).withAlpha(100),
                                blurRadius: 8,
                              ),
                            ],
                          ),
                          child: Icon(
                            _categoryIcon(center.category),
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                      )).toList(),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),

            // Service list
            Expanded(
              flex: 2,
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: _filteredCenters.length,
                itemBuilder: (context, index) {
                  final center = _filteredCenters[index];
                  return Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            color: _categoryColor(center.category).withAlpha(30),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Icon(
                            _categoryIcon(center.category),
                            color: _categoryColor(center.category),
                            size: 20,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(center.name, style: Theme.of(context).textTheme.titleSmall?.copyWith(
                                color: AppColors.textPrimary,
                              )),
                              const SizedBox(height: 2),
                              Row(
                                children: [
                                  const Icon(Icons.star, size: 14, color: AppColors.warning),
                                  const SizedBox(width: 3),
                                  Text('${center.rating}', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                                  const SizedBox(width: 8),
                                  const Icon(Icons.location_on, size: 14, color: AppColors.textTertiary),
                                  const SizedBox(width: 2),
                                  Text(center.distance, style: const TextStyle(fontSize: 12, color: AppColors.textTertiary)),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.navigation, color: AppColors.primary, size: 20),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _categoryColor(String cat) {
    switch (cat) {
      case 'diagnostics': return AppColors.primary;
      case 'electrician': return AppColors.warning;
      case 'engine': return AppColors.accentPurple;
      default: return AppColors.textSecondary;
    }
  }

  IconData _categoryIcon(String cat) {
    switch (cat) {
      case 'diagnostics': return Icons.search;
      case 'electrician': return Icons.electrical_services;
      case 'engine': return Icons.build;
      default: return Icons.location_on;
    }
  }
}

class _CategoryChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool isActive;
  final VoidCallback onTap;

  const _CategoryChip({
    required this.label,
    required this.icon,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: isActive ? AppColors.primary.withAlpha(30) : AppColors.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isActive ? AppColors.primary : AppColors.border,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 16, color: isActive ? AppColors.primary : AppColors.textTertiary),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                fontSize: 13,
                color: isActive ? AppColors.primary : AppColors.textSecondary,
                fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ServiceCenter {
  final String name;
  final String category;
  final double lat;
  final double lng;
  final double rating;
  final String distance;

  _ServiceCenter(this.name, this.category, this.lat, this.lng, this.rating, this.distance);
}
