import '../../../data/models/dtc_code.dart';
import '../../../data/models/live_data.dart';
import '../../../data/models/vehicle_info.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

abstract class ObdDataSource {
  bool get isConnected;
  
  /// In demo mode device is null, in real mode it requires BluetoothDevice
  Future<bool> connect([BluetoothDevice? device]);
  
  void disconnect();
  
  VehicleInfo getVehicleInfo();
  
  Stream<LiveData> getLiveDataStream();
  
  Future<List<DtcCode>> readDtcCodes();
  
  Future<bool> clearDtcCodes();
}
