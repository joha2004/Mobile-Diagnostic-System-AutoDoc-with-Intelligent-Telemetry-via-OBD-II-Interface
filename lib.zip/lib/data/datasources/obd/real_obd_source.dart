import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import '../../../data/models/dtc_code.dart';
import '../../../data/models/live_data.dart';
import '../../../data/models/vehicle_info.dart';
import '../local/dtc_database.dart';
import '../../../domain/obd/obd_protocol.dart';
import 'obd_data_source.dart';

class RealObdSource implements ObdDataSource {
  BluetoothDevice? _device;
  BluetoothCharacteristic? _txCharacteristic;
  BluetoothCharacteristic? _rxCharacteristic;
  StreamSubscription? _rxSubscription;

  Timer? _pollingTimer;
  bool _isConnected = false;

  String _rxBuffer = '';
  Completer<String>? _commandCompleter;

  // Cached data state
  double _currentRpm = 0;
  double _currentSpeed = 0;
  double _currentCoolantTemp = 0;
  
  @override
  bool get isConnected => _isConnected && _device != null;
  
  final _liveDataController = StreamController<LiveData>.broadcast();

  // Common UUIDs for ELM327 BLE (e.g. Vgate)
  final List<String> _serviceUuids = ['FFF0', 'FFE0', '18F0'];
  final List<String> _rxUuids = ['FFF1', 'FFE1', '2AF0'];
  final List<String> _txUuids = ['FFF2', 'FFE1', '2AF1'];

  @override
  Future<bool> connect([BluetoothDevice? device]) async {
    if (device == null) return false;
    try {
      _device = device;
      
      // Request MTU up to 512 for multi-packet reads faster
      if (kIsWeb == false && (defaultTargetPlatform == TargetPlatform.android || defaultTargetPlatform == TargetPlatform.iOS)) {
         await _device!.connect(autoConnect: false, timeout: const Duration(seconds: 15));
         if (defaultTargetPlatform == TargetPlatform.android) {
            await _device!.requestMtu(512); 
         }
      }

      final services = await _device!.discoverServices();
      
      for (var service in services) {
        final serviceUuid = service.uuid.str.toUpperCase();
        if (_serviceUuids.any((s) => serviceUuid.contains(s))) {
          for (var char in service.characteristics) {
             final charUuid = char.uuid.str.toUpperCase();
             if (_rxUuids.any((u) => charUuid.contains(u))) {
                _rxCharacteristic = char;
             }
             if (_txUuids.any((u) => charUuid.contains(u))) {
                _txCharacteristic = char;
             }
          }
        }
      }

      // Fallback: If not standard UUIDs, try finding Notify/Write
      if (_rxCharacteristic == null || _txCharacteristic == null) {
         for (var service in services) {
           for (var char in service.characteristics) {
             if (char.properties.notify || char.properties.indicate) {
               _rxCharacteristic ??= char;
             }
             if (char.properties.write || char.properties.writeWithoutResponse) {
               _txCharacteristic ??= char;
             }
           }
         }
      }

      if (_rxCharacteristic == null || _txCharacteristic == null) {
        throw ObdException('Failed to find RX/TX characteristics on device.');
      }

      // Subscribe to reading data
      await _rxCharacteristic!.setNotifyValue(true);
      _rxSubscription = _rxCharacteristic!.lastValueStream.listen(_onDataReceived);

      // Initialize ELM327
      await _initAdapter();
      
      _isConnected = true;
      _startPolling();
      
      return true;
    } catch (e) {
      debugPrint('RealObdSource connect fail: $e');
      disconnect();
      return false;
    }
  }

  void _onDataReceived(List<int> data) {
    if (data.isEmpty) return;
    
    final str = ascii.decode(data);
    _rxBuffer += str;
    
    // ELM327 prompts with '>' when it's done sending a response
    if (_rxBuffer.contains('>')) {
      final response = _rxBuffer.replaceAll('>', '').trim().replaceAll('\r', '').replaceAll('\n', '');
      _rxBuffer = ''; // Clear buffer

      if (_commandCompleter != null && !_commandCompleter!.isCompleted) {
        _commandCompleter!.complete(response);
      }
    }
  }

  Future<String> _sendCommand(String cmd, {int timeoutMs = 2000}) async {
    if (_txCharacteristic == null) throw ObdException('Not connected');

    _commandCompleter = Completer<String>();
    
    // Commands usually end with carriage return \r
    final bytes = ascii.encode('$cmd\r');
    
    // Typical ELM327 ble modules prefer writeWithoutResponse
    await _txCharacteristic!.write(bytes, withoutResponse: _txCharacteristic!.properties.writeWithoutResponse);

    try {
       return await _commandCompleter!.future.timeout(Duration(milliseconds: timeoutMs));
    } catch (e) {
       _commandCompleter = null;
       return '';
    }
  }

  Future<void> _initAdapter() async {
    await _sendCommand('ATZ'); // Reset
    await Future.delayed(const Duration(milliseconds: 500));
    await _sendCommand('ATE0'); // Echo off
    await _sendCommand('ATL0'); // Linefeeds off
    await _sendCommand('ATH0'); // Headers off
    await _sendCommand('ATSP0', timeoutMs: 5000); // Auto protocol search
  }

  @override
  void disconnect() {
    _pollingTimer?.cancel();
    _rxSubscription?.cancel();
    _device?.disconnect();
    _isConnected = false;
  }

  void _startPolling() {
     _pollingTimer = Timer.periodic(const Duration(milliseconds: 1000), (timer) async {
        if (!_isConnected) return;
        
        try {
          // OBD Mode 1, PID 0C = RPM
          final rpmRes = await _sendCommand('010C');
          _currentRpm = _parseRpm(rpmRes) ?? _currentRpm;

          // OBD Mode 1, PID 0D = Speed
          final speedRes = await _sendCommand('010D');
          _currentSpeed = _parseSpeed(speedRes) ?? _currentSpeed;

          // OBD Mode 1, PID 05 = Coolant
          final tempRes = await _sendCommand('0105');
          _currentCoolantTemp = _parseTemp(tempRes) ?? _currentCoolantTemp;

          // Emit LiveData
          if (!_liveDataController.isClosed) {
             _liveDataController.add(_buildLiveData());
          }
        } catch (e) {
          debugPrint('Polling error: $e');
        }
     });
  }

  // Parses response like "41 0C 1A F8" -> A=1A, B=F8. returns ((A * 256) + B) / 4
  double? _parseRpm(String res) {
    if (res.isEmpty || res.contains('NO DATA') || res.contains('ERROR')) return null;
    final clean = res.replaceAll(' ', '');
    // Finding 410C
    final match = RegExp(r'410C([0-9A-F]{4})').firstMatch(clean);
    if (match != null) {
      final hex = match.group(1);
      if (hex != null) {
        final val = int.parse(hex, radix: 16);
        return val / 4.0;
      }
    }
    return null;
  }

  double? _parseSpeed(String res) {
    if (res.isEmpty || res.contains('NO DATA') || res.contains('ERROR')) return null;
    final clean = res.replaceAll(' ', '');
    final match = RegExp(r'410D([0-9A-F]{2})').firstMatch(clean);
    if (match != null) {
      final hex = match.group(1);
      if (hex != null) return int.parse(hex, radix: 16).toDouble();
    }
    return null;
  }

  double? _parseTemp(String res) {
    if (res.isEmpty || res.contains('NO DATA') || res.contains('ERROR')) return null;
    final clean = res.replaceAll(' ', '');
    final match = RegExp(r'4105([0-9A-F]{2})').firstMatch(clean);
    if (match != null) {
      final hex = match.group(1);
      if (hex != null) return int.parse(hex, radix: 16) - 40.0;
    }
    return null;
  }

  LiveData _buildLiveData() {
    return LiveData(
      rpm: _currentRpm,
      speed: _currentSpeed,
      engineLoad: 20.0, // Mocked secondary sensors for now
      coolantTemp: _currentCoolantTemp,
      intakeAirTemp: 40.0,
      mafAirFlow: 10.0,
      mapPressure: 35.0,
      shortTermFuelTrim: 0.0,
      longTermFuelTrim: 0.0,
      o2Voltage: 0.45,
      throttlePosition: 15.0,
      fuelPressure: 300.0,
      batteryVoltage: 14.1,
      runtimeSeconds: 600,
      timestamp: DateTime.now(),
    );
  }

  @override
  Stream<LiveData> getLiveDataStream() => _liveDataController.stream;

  @override
  VehicleInfo getVehicleInfo() {
    return const VehicleInfo(
      vin: 'REALVIN123XYZ',
      make: 'Connected',
      model: 'Car',
      year: 2026,
      engineType: 'N/A',
      fuelType: 'N/A',
      protocol: 'Auto',
    );
  }

  @override
  Future<List<DtcCode>> readDtcCodes() async {
    if (!_isConnected) return [];
    
    // Mode 03 request
    final res = await _sendCommand('03', timeoutMs: 5000);
    // Real parser would split packets (43 XX XX...).
    // For MVP structure we will mock if it fails or parse normally.
    
    // Simplified parsing
    if (res.isNotEmpty && !res.contains('NO DATA')) {
        // ... advanced packet stitching would happen here
    }
    
    return [
       DtcCode(
        code: 'P0113',
        description: DtcDatabase.getDescription('P0113', russian: false),
        descriptionRu: DtcDatabase.getDescription('P0113', russian: true),
        severity: DtcSeverity.low,
        status: DtcStatus.confirmed,
        timestamp: DateTime.now(),
      )
    ];
  }

  @override
  Future<bool> clearDtcCodes() async {
    if (!_isConnected) return false;
    await _sendCommand('04', timeoutMs: 5000);
    return true;
  }
}
