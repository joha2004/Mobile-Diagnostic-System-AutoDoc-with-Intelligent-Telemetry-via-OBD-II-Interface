import 'dart:convert';
import 'package:google_generative_ai/google_generative_ai.dart';
import '../../models/diagnostic_result.dart';
import '../../models/ai_explanation.dart';

/// Gemini AI integration for explaining diagnostic results in simple language
class GeminiService {
  final String apiKey;
  
  GeminiService({
    required this.apiKey,
  });

  bool get isConfigured => apiKey.isNotEmpty && apiKey != 'your_gemini_api_key_here';

  /// Get AI explanation for a diagnostic result
  Future<AiExplanation> explain({
    required DiagnosticResult result,
    required String languageCode,
  }) async {
    if (!isConfigured) {
      throw Exception('Gemini API key not configured');
    }

    final isRussian = languageCode == 'ru';
    final systemPrompt = _buildSystemPrompt(isRussian);
    final userPrompt = _buildUserPrompt(result, isRussian);

    try {
      final model = GenerativeModel(
        model: 'gemini-1.5-flash',
        apiKey: apiKey,
        systemInstruction: Content.system(systemPrompt),
        generationConfig: GenerationConfig(
          responseMimeType: 'application/json',
          temperature: 0.4,
        ),
      );

      final response = await model.generateContent([
        Content.text(userPrompt)
      ]);

      if (response.text != null) {
        final content = response.text!;
        final parsed = jsonDecode(content) as Map<String, dynamic>;
        return AiExplanation.fromApiResponse(result.dtcCode, parsed);
      } else {
        throw Exception('API error: null response');
      }
    } catch (e) {
      // Return offline explanation on failure
      return AiExplanation.offline(
        dtcCode: result.dtcCode,
        description: result.causes.isNotEmpty 
            ? (isRussian ? result.causes.first.descriptionRu : result.causes.first.description)
            : 'Analysis error',
      );
    }
  }

  String _buildSystemPrompt(bool isRussian) {
    if (isRussian) {
      return '''Ты — передовой ИИ-помощник автодиагноста. Твоя задача — ОБЪЯСНЯТЬ результаты диагностики понятным, простым языком для водителя. 
Ты НЕ диагностируешь с нуля — ты блестяще переводишь готовый анализ на понятный язык.

Правила:
- Говори простым языком, без сложного технического жаргона.
- Не пугай пользователя, описывай ситуацию объективно.
- Указывай четкий план действий.

Ответь СТРОГО в JSON формате без Markdown оберток:
{
  "problem": "Коротко суть проблемы так, чтобы поняла твоя бабушка",
  "symptoms": "Как это ощущается при вождении автомобиля",
  "danger_level": "Низкая" | "Средняя" | "Высокая",
  "can_drive": "Да" | "Да, но аккуратно" | "Нет, эвакуатор",
  "causes": [
    {"description": "Самая вероятная причина", "probability": 85},
    {"description": "Вторая причина", "probability": 60}
  ],
  "repair_cost": "Примерная вилка цен на ремонт",
  "specialist": "К какому мастеру ехать (Автоэлектрик, Моторист, Ходовщик)",
  "confidence": 85
}''';
    } else {
      return '''You are an advanced AI auto-diagnostic assistant. Your job is to EXPLAIN diagnostic results in simple language for car owners.
You do NOT diagnose from scratch — you brilliantly translate technical analysis into clear language.

Rules:
- Use simple, direct, non-technical language.
- Don't overly panic the user, state facts practically.
- Give a clear action plan.

Respond STRICTLY in JSON format without Markdown wrapping:
{
  "problem": "Explain the problem so simple that a beginner driver understands",
  "symptoms": "How this actually feels while driving the car",
  "danger_level": "Low" | "Medium" | "High",
  "can_drive": "Yes" | "Yes, but carefully" | "No, call tow truck",
  "causes": [
    {"description": "Most probable cause", "probability": 85},
    {"description": "Secondary cause", "probability": 60}
  ],
  "repair_cost": "Estimated cost range for repair",
  "specialist": "Type of mechanic needed (Auto Electrician, Engine Mechanic)",
  "confidence": 85
}''';
    }
  }

  String _buildUserPrompt(DiagnosticResult result, bool isRussian) {
    final context = result.toAiContext();
    
    if (isRussian) {
      return '''Проанализируй эти диагностические данные:
Код ошибки: ${result.dtcCode}
Датчики и параметры (Двигатель, Топливо, Электрика): ${jsonEncode(context)}
Уверенность авто-модуля: ${result.confidencePercent}%
Общая серьезность: ${result.overallSeverity}

Сгенерируй ответ в JSON, строго следуя System Instructions.''';
    } else {
      return '''Analyze these diagnostic data points:
Error code: ${result.dtcCode}
Sensors & Params: ${jsonEncode(context)}
Auto-module confidence: ${result.confidencePercent}%
Overall Severity: ${result.overallSeverity}

Generate a JSON response strictly following System Instructions.''';
    }
  }
}
